 
code�Gmain.cpp parser.cpp parser.h

����G
 ./pal c1.bench cell.genlib c1.rpt

 ./pal c17.bench cell.genlib c17.rpt

 ./pal c432.bench cell.genlib c432.rpt